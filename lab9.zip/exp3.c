#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>

void *f1()
{
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    while (1)
    {
        printf("\nThis is thread 1");
    }
}

void *f2()
{
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);

    while (1)
    {
        for (int i = 0; i < 2; i++)
        {
            printf("\nThis is thread 2");
        }
        pthread_testcancel();
    }
}

int main()
{
    pthread_t pid1, pid2;
    pthread_create(&pid1, NULL, &f1, (void *)NULL);
    pthread_create(&pid2, NULL, &f2, (void *)NULL);

    sleep(5);

    pthread_cancel(pid1);
    pthread_cancel(pid2);

    pthread_join(pid1, NULL);
    pthread_join(pid2, NULL);

    return 0;
}
