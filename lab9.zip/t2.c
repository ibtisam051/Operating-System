#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_mutex_t mutex;

void *MaclaurinSeries(void *ptr)
{
    long *bounds = (long *)ptr;
    long lowerBound = bounds[0];
    long upperBound = bounds[1];

    printf("Lower Bound: %ld\n", lowerBound);
    printf("Upper Bound: %ld\n", upperBound);

    float series = 0;
    for (int i = lowerBound; i <= upperBound; i++)
    {
        pthread_mutex_lock(&mutex);

        float minus1PowerN = 1;
        float x = (2 * i) + 1; // 1,3,5,7
        float xPower2N = 1;

        for (int j = 0; j < i; j++) // for (-1)^n
        {
            minus1PowerN = minus1PowerN * -1;
        }
        for (int k = 0; k < x; k++) // for (2)^2n+1
        {
            xPower2N = xPower2N * 2;
        }

        series = minus1PowerN * (xPower2N / x); //(-1)^n * ((2^2n+1)/2^n+1)

        printf("->Series %f\n", series);
        pthread_mutex_unlock(&mutex);
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc - 1 == 0)
    {
        printf("No Input.\n");
    }
    else if (argc - 1 != 2)
    {
        printf("Invalid Input.\n");
    }
    else
    {
        int noOfThreads = atoi(argv[1]);
        long N = atoi(argv[2]);

        printf("No. Of Threads: %d\n", noOfThreads);
        printf("N is: %ld\n", N);

        if (N % noOfThreads == 0)
        {
            printf("\nYes evenly divisible.\n");
            if (N > 100000)
            {
                printf("Yes 100000.\n\n");

                pthread_t threads[noOfThreads];

                long r = N / noOfThreads; // 20/5 = 4
                long lowerBound = 0;
                long upperBound = 0;
                upperBound = lowerBound + (r - 1); // 0+3= 3

                long Bounds[2]; // array for upper and lower bound

                pthread_mutex_init(&mutex, NULL);
                for (int i = 0; i < noOfThreads; i++)
                {
                    Bounds[0] = lowerBound;
                    Bounds[1] = upperBound;

                    if (pthread_create(&threads[i], NULL, &MaclaurinSeries, (void *)Bounds) != 0)
                    {
                        printf("Threads creation failed.\n");
                        exit(-1);
                    }

                    printf("\n");

                    if (pthread_join(threads[i], NULL) != 0)
                    {
                        printf("Threads joining failed.\n");
                        exit(-1);
                    }

                    // updating the bounds after 1st thread
                    lowerBound = upperBound + 1;
                    upperBound += r;
                }
                pthread_mutex_destroy(&mutex);
            }
            else
            {
                printf("Not greater than 100000.\n");
                exit(-1);
            }
        }
        else
        {
            printf("Not evenly divisible.\n");
            exit(-1);
        }
    }
    return 0;
}