#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <sys/file.h>

char *fileName;
char *string;
int noOfThreads = 0;
int flag = 0;

void *SearchString(void *ptr)
{
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
    printf("\nFileName: %s\n", fileName);
    printf("String: %s\n", string);

    char word[100];
    int col = 0;
    int line = 0;

    FILE *file = fopen(fileName, "r");

    if (file != NULL)
    {
        while (1)
        {
            fscanf(file, "%s", word);
            col++;

            if (strcmp(word, "\n") == 0)
            {
                printf("New Line\n");
                line++;
                col = 0;
            }
            if (strcmp(word, string) == 0)
            {
                printf("Found the string in column %d and lineNo %d\n", col, line);
                flag = 1;
                fclose(file);
            }

            if (feof(file))
            {
                fclose(file);
                pthread_exit(NULL);
                break;
            }
        }
    }
    else
    {
        printf("File not open.\n");
    }

    fclose(file);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc - 1 == 0)
    {
        printf("No Input.\n");
    }
    else if (argc - 1 != 3)
    {
        printf("Invalid inputs.\n");
    }
    else
    {
        printf("Yes.\n");

        fileName = argv[1];
        noOfThreads = atoi(argv[2]);
        string = argv[3];

        printf("\nFileName: %s\n", fileName);
        printf("NoOfThreads %d\n", noOfThreads);
        printf("String: %s\n", string);

        pthread_t threads[noOfThreads]; // 3 threads will be created

        for (int i = 0; i < noOfThreads; i++)
        {
            if (pthread_create(&threads[i], NULL, &SearchString, NULL) != 0)
            {
                printf("Threads creation failed.\n");
                exit(-1);
            }
        }

        int j = 0;
        while (1)
        {
            if (flag == 1)
            {
                j++;

                // if the word is found we will cancel other threads using deffered
                pthread_cancel(threads[j]);
                if (pthread_join(threads[j], NULL) != 0)
                {
                    printf("Threads joining failed.\n");
                    exit(-1);
                }

                if (j == noOfThreads)
                {
                    break;
                }
            }
        }
        for (int i = 0; i < noOfThreads; i++)
        {
            pthread_exit((void *)threads[i]);
        }
    }

    return 0;
}