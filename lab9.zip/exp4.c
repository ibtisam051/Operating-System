#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void *f1(void *ptr)
{
    printf("\nThis is thread 1");
    return 0;
}

int main()
{
    pthread_t pid1;
    size_t stacksize;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_getstacksize(&attr, &stacksize);
    printf("\nCurrent size of stack is%d", (int)stacksize);
    pthread_attr_setstacksize(&attr, 1024 * 1024 * 16); /*setting stack to 16 MB*/
    pthread_create(&pid1, &attr, &f1, (void *)NULL);
    pthread_join(pid1, NULL);
    pthread_attr_destroy(&attr);
    return 0;
}