#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include <pthread.h>

int size = 0;

void *evenCheck(void *ptr)
{
    int *nptr = (int *)ptr;
    int c = 0;
    printf("The even no are: ");
    for (int i = 0; i < size; i++)
    {
        if (nptr[i] % 2 == 0)
        {
            printf("%d ", nptr[i]);
        }
        else
        {
            c++;
        }
    }

    if (c == size)
    {
        printf("No even numbers in the array...\n");
    }
    return 0;
}

void *oddCheck(void *ptr)
{
    int *nptr = (int *)ptr;
    int c = 0;
    printf("\nThe odd no are: ");
    for (int i = 0; i < size; i++)
    {
        if (nptr[i] % 2 != 0)
        {
            printf("%d ", nptr[i]);
        }
        else
        {
            c++;
        }
    }

    if (c == size)
    {
        printf("No odd numbers in the array...\n");
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc - 1 == 0)
    {
        printf("No Input.\n");
    }
    else
    {
        size = argc - 1;
        int *ptr = (int *)malloc((argc - 1) * sizeof(int));
        for (int i = 0; i < argc - 1; i++)
        {
            ptr[i] = atoi(argv[i + 1]);
        }

        pthread_t thd1, thd2;

        int c1 = pthread_create(&thd1, NULL, &evenCheck, ptr);
        if (c1 != 0)
        {
            printf("Error..\n");
            exit(-1);
        }
        printf("\n");

        int c2 = pthread_join(thd1, NULL);
        if (c2 != 0)
        {
            printf("Error..\n");
            exit(-1);
        }

        int c3 = pthread_create(&thd2, NULL, &oddCheck, ptr);
        if (c3 != 0)
        {
            printf("Error..\n");
            exit(-1);
        }

        int c4 = pthread_join(thd2, NULL);
        if (c4 != 0)
        {
            printf("Error..\n");
            exit(-1);
        }

        printf("\n");
        pthread_exit((void *)thd1);
        pthread_exit((void *)thd2);
    }

    return 0;
}