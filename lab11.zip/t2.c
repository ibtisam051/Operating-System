#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

pthread_mutex_t mutex;
sem_t chopstick[5];

void *Function(void *n)
{
    int ph = *(int *)n;

    //ENTRY SECTION
    printf("Philosopher %d wants to eat\n", ph);
    printf("Philosopher %d tries to pick left chopstick\n", ph);

    pthread_mutex_lock(&mutex);
    sem_wait(&chopstick[ph]);
    printf("Philosopher %d picks the left chopstick\n", ph);

    printf("Philosopher %d tries to pick the right chopstick\n", ph);
    sem_wait(&chopstick[(ph + 1) % 5]);
    printf("Philosopher %d picks the right chopstick\n", ph);
    pthread_mutex_unlock(&mutex);

    //CRITICAL SECTION
    printf("Philosopher %d begins to eat\n", ph);
    sleep(2);
    printf("Philosopher %d has finished eating\n", ph);

    //EXIT SECTION
    sem_post(&chopstick[(ph + 1) % 5]);
    printf("Philosopher %d leaves the right chopstick\n", ph);
    sem_post(&chopstick[ph]);
    printf("Philosopher %d leaves the left chopstick\n", ph);
    return 0;
}

int main()
{
    int i, n[5];
    pthread_t T[5];
    pthread_mutex_init(&mutex, NULL);

    for (i = 0; i < 5; i++)
    {
        sem_init(&chopstick[i], 0, 1);
    }
    for (i = 0; i < 5; i++)
    {
        n[i] = i;
        if (pthread_create(&T[i], NULL, &Function, (void *)&n[i]) != 0)
        {
            printf("Thread no created.\n");
            exit(-1);
        }
    }
    for (i = 0; i < 5; i++)
    {
        if (pthread_join(T[i], NULL) != 0)
        {
            printf("Thread no joining.\n");
            exit(-1);
        }
    }

    pthread_mutex_destroy(&mutex);

    return 0;
}