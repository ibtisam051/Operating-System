#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

unsigned int count = 0; // for no of readers accessing the resource

sem_t mutex;
sem_t mutex_1;

void *reader(void *ptr)
{
    int r = (*(int *)ptr);

    sem_wait(&mutex_1); // to make it sequential and not interrupt the reader1
    count++;            //checking for the first reader IN

    //ENTRY SECTION
    if (count == 1)
    {
        sem_wait(&mutex);
    }
    sem_post(&mutex_1); // again releasing it

    //CRITICAL SECTION
    printf("I'm reader %d and i'm reading...\n", r);

    sem_wait(&mutex_1);
    count--; //first reader OUT

    //EXIT SECTION
    if (count == 0)
    {
        sem_post(&mutex);
    }
    sem_post(&mutex_1);

    return 0;
}

void *writer(void *ptr)
{

    int w = (*(int *)ptr);

    sem_wait(&mutex_1);
    //entry section
    sem_wait(&mutex);

    //critical section
    printf("I'm writer %d and i'm writing...\n", w);

    //exit section
    sem_post(&mutex);
    sem_post(&mutex_1);

    return 0;
}

int main()
{
    sem_init(&mutex, 0, 1);   // initializing it to 1
    sem_init(&mutex_1, 0, 1); // initializing it to 1

    pthread_t read[6];  // for reader
    pthread_t write[3]; // for writer
    int n[6];
    int n2[3];

    //CREATING THREADS
    for (int i = 0; i < 6; i++)
    {
        n[i] = i;
        if (pthread_create(&read[i], NULL, &reader, (void *)&n[i]) != 0)
        {
            printf("Thread not created.\n");
            exit(-1);
        }
    }
    // printf("\n");

    for (int i = 0; i < 3; i++)
    {
        n2[i] = i;
        if (pthread_create(&write[i], NULL, &writer, (void *)&n2[i]) != 0)
        {
            printf("Thread not created.\n");
            exit(-1);
        }
    }

    //JOINING THREADS
    for (int i = 0; i < 6; i++)
    {
        if (pthread_join(read[i], NULL) != 0)
        {
            printf("Thread not joined.\n");
            exit(-1);
        }
    }
    for (int i = 0; i < 3; i++)
    {
        if (pthread_join(write[i], NULL) != 0)
        {
            printf("Thread not joined.\n");
            exit(-1);
        }
    }
    return 0;
}